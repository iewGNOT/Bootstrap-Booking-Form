const dailyCost = 150;
var In, Out, num, days, cost, today, valid, id, i;
let blank;
var ids = [
    'user_name',
    'first_name',
    'last_name',
    'phone',
    'fax',
    'email',
    'Check-In',
    'Check-Out'
];
$('#days').val('');
$('#cost').val('');

$(document).ready(function () {
    $('#Check-In, #Check-Out').change(function () {
        update();
    });

    $('#num').change(function () {
        update();
    });

    $('#reset').click(function () {
        reset();
    });

    $('#submit').click(function (q) {
        q.preventDefault();
        if (validate()) {
            submit();
        }
    });
});

function update() {
    In = $('#Check-In').val();
    Out = $('#Check-Out').val();
    num = $('#num').val();

    days = moment(Out).diff(moment(In), 'days');
    cost = days * num * dailyCost;
    $('#days').val(days);
    $('#cost').val(cost);
}

function reset() {
    toastr.info('Reset successfully', 'Info');
    $('input').val('');
    $('.form-group').removeClass('has-error');
}

function validate() {
    valid = true;

    for (i = 0; i < ids.length; i++) {
        id = ids[i];
        blank = $('#' + id);
        if (!blank.val().trim()) {
            blank.closest('.form-group').addClass('has-error');
            toastr.error(id + ' does not exist', 'Error');
            valid = false;
        }
        else {
            if (id === 'Check-In') {
                today = moment();
                if (moment(blank.val(), 'YYYY-MM-DD').isBefore(today, 'day')) {
                    blank.closest('.form-group').addClass('has-error');
                    toastr.error('Check-In date should be a future date.', 'Error');
                    valid = false; 
                }
                else {
                    blank.closest('.form-group').removeClass('has-error');
                }
            }
            else {
                blank.closest('.form-group').removeClass('has-error');
            }
        }
    }
    return valid;
}

function submit() {
    cost = $('#cost').val();

    if (!cost || cost < 0) {
        toastr.error(cost ? 'Negative Cost' : 'No cost.', 'Error');
        return;
    }

    toastr.success('Submitted successfully', 'Success');
    reset();
}
